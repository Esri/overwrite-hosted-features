Overview:
   Each tool in the toolboxes was developed using ArcREST.  To get the tools working, download ArcREST and run the setup.py install from command line.
   The tool's help is outlined in each script.

