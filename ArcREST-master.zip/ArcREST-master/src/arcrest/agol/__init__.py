from __future__ import absolute_import
from .services import FeatureService, FeatureLayer, TableLayer, TiledService
from . import helperservices
from ._uploads import Uploads

__version__ = "3.5.3"
